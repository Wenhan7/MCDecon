function [m,h,t] = MCDecon_ADMM(Z,R,dt,tshft,mu,beta,tol,max_iter,spat_constr,lf,mu_fx,flow,fhigh)

% This function performs robust multichannel sparse deconvolution that 
% estimates multi-trace receiver function simultaneously. 
% The method incorporates an f-x prediction filter to reduce the
% sensitivity of deconvolution to the presence of noise on seismograms.
%
% Reference: Sun, W., Sacchi, M. D., & Gu, Y. J. (2023). 
% Multichannel Sparse Deconvolution of Teleseismic Receiver Functions with
% f-x Preconditioning . Journal of Geophysical Research: Solid Earth, accepted.

% Written by: Wenhan Sun, Department of Physics, University of Alberta
% Update Date: 2023/03/28
%
%
% Mandatory Input:
% Z: Multichannel vertical-component seismograms (size: [Nt,Ntraces])
% R: Multichannel radial-component seismograms (size: [Nt,Ntraces])
% dt: sampling rate of the seismograms (s)
%
% Optional Input:
% tshft: time shift of the receiver functions after deconvolution. (default: 10s)
% mu: trade-off parameter (default: 0.001)
% beta: scaling factor (default: 1)
% tol: tolerance (default: 0.001)
% max_iter: maximum iterations (20)
% spat_constr: whether or not apply spatial constraints via the f-x prediction filter
% (0: no constraint, 1: constraint; default: 1)
% (The following parameters will not function if spat_constr=0 )
% lf: length of the f-x prediction filter  (default: 7)
% mu_fx: regularization parameter in the f-x prediction filter
% flow: low-cut frequency (Hz) for f-x prediction filter (default: 0)
% fhigh: high-cut frequency (Hz) for f-x prediction filter (default: 1/dt/2)

% Output:
% m: Multichannel receiver functions (size: [Nt,Ntrace])
% h: trace index [1:Ntrace]
% t: time of receiver functions after time shift.

% Setting the default values

if nargin == 12, fhigh = 1/dt/2; end
if nargin == 11, flow = 0; end
if nargin == 10, mu_fx = 0.1; end
if nargin == 9, lf = 7; end
if nargin == 8, spat_constr = 1; end
if nargin == 7, max_iter = 20; end
if nargin == 6, tol = 0.001; end
if nargin == 5, beta = 1; end
if nargin == 4, mu = 0.003; end


[Nt,Ntraces] = size(Z); % get the dimension of the multi-trace seismograms

nf = 2^nextpow2(Nt); % number of samples in frequency domian (zero padding)

Zf = fft(Z,nf); % Initializations
Rf = fft(R,nf);

m0 = zeros(nf,Ntraces);
m = zeros(size(m0));

x = zeros(nf,Ntraces); % auxiliary variable used in Split Bregman iteration
b = zeros(nf,Ntraces); % auxiliary variable used in Split Bregman iteration
k = 0;

D = 1./(abs(Zf).^2+beta/2); 

while(k<max_iter)
    m = real(ifft(D.*(conj(Zf).*Rf + beta/2*fft(x-b)))); % frequency-domain inversion
    if(spat_constr)
        m_fx = fx_decon(m,dt,lf,mu_fx,flow,fhigh); % apply f-x preconditioning
    else
        m_fx = m; % no f-x preconditioning, the code returns to single-channel sparse decon.
    end
    if((norm(m_fx-m0)/Ntraces)<tol) % check if need to terminate or not
        m0 = m_fx;
        break;
    else
        m0 = m_fx;
    end
    x = (m0 + b)./abs(m0+b+eps).*max(abs(m0+b)-mu/(beta+eps),0); % soft-thresholding
    b = b + m0 - x;
    k = k + 1;
    fprintf('Iteration No. %d\n',k)
end

freq = zeros(nf,1); % Frequencies
freq(1:nf/2+1) = (0:(nf/2))/nf/dt;
freq(nf/2+2:end) = -1*freq(nf/2:-1:2);

shft = repmat(exp(-1*sqrt(-1)*tshft*2*pi*freq),[1,Ntraces]); % Shift the receiver functions by time
m = real(ifft(fft(m0).*shft));
m = m(1:Nt,:);
t = [0:Nt-1]'*dt-tshft;
h = [1:Ntraces];

end
