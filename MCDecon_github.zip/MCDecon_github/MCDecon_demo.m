clear;

tshft = 10; dt = 0.05; Nt = 1000; Ntraces = 30;

% params. for MC-decon.
mu = 0.003; beta = 1; tol = 0.001; max_iter = 20; spat_constr = 1;
lf = 7; mu_fx = 0.1; flow = 0; fhigh = 10;

% load the synthetic data and additive noise
load('seis.mat'); 
load('rdm_noi.mat');

seis_R = R;
seis_Z = Z;

% scale the noise and add it to the seismograms
a = 0.5;

seis_Rn = seis_R + a*rdm_noi;
seis_Zn = seis_Z + a*rdm_noi;
    
% scale the data
seis_R1 = seis_R/norm(seis_Rn);
seis_Z1 = seis_Z/norm(seis_Zn);
seis_Rn = seis_Rn/norm(seis_Rn);
seis_Zn = seis_Zn/norm(seis_Zn);

noi_R = seis_Rn-seis_R1;
snrR = 20*log10(norm(seis_R1(:))/norm(noi_R(:)));

disp(['noise level (norm): ',num2str(snrR),'(dB)']);

% multichannel deconvolution
[rf_mc,trace,t_rf] = MCDecon_ADMM(seis_Zn,seis_Rn,dt,tshft,mu,beta,tol,max_iter,spat_constr,lf,mu_fx,flow,fhigh);


% visualizations
figure; wigb(seis_Z(1:Nt,1:Ntraces),2,[1:Ntraces],[dt*(0:Nt-1)-tshft]);
ylabel('Time (s)','Fontsize',20);
xlabel('Traces','Fontsize',20);
yticks([0 10 20 30 40]);
title('Vertical Seismograms (clean)','Fontsize',16);
set(gca,'Fontsize',20,'Linewidth',1.2,'position',[0.23 0.17 0.55 0.73],'XAxisLocation','bottom');
text(15,2.5,'P','color','k','FontSize',15,'Fontweight','bold');
text(15,7,'Ps','color','k','FontSize',15,'Fontweight','bold');
text(15,18.5,'PpPs','color','k','FontSize',15,'Fontweight','bold');
text(15,23.5,'PpSs+PsPs','color','k','FontSize',15,'Fontweight','bold');
set(gcf,'position',[600,400,550,420]);

figure; wigb(seis_R(1:Nt,1:Ntraces),2,[1:Ntraces],[dt*(0:Nt-1)-tshft]);
ylabel('Time (s)','Fontsize',20);
xlabel('Traces','Fontsize',20);
yticks([0 10 20 30 40]);
title('Radial Seismograms (clean)','Fontsize',16);
set(gca,'Fontsize',20,'Linewidth',1.2,'position',[0.23 0.17 0.55 0.73],'XAxisLocation','bottom');
text(15,2.5,'P','color','k','FontSize',15,'Fontweight','bold');
text(15,7,'Ps','color','k','FontSize',15,'Fontweight','bold');
text(15,18.5,'PpPs','color','k','FontSize',15,'Fontweight','bold');
text(15,23.5,'PpSs+PsPs','color','k','FontSize',15,'Fontweight','bold');
set(gcf,'position',[600,400,550,420]);

figure; wigb(seis_Zn(1:Nt,1:Ntraces),2,[1:Ntraces],[dt*(0:Nt-1)-tshft]);
ylabel('Time (s)','Fontsize',20);
xlabel('Traces','Fontsize',20);
yticks([0 10 20 30 40]);
title('Vertical Seismograms (noisy)','Fontsize',16);
set(gca,'Fontsize',20,'Linewidth',1.2,'position',[0.23 0.17 0.55 0.73],'XAxisLocation','bottom');
text(15,2.5,'P','color','k','FontSize',15,'Fontweight','bold');
text(15,7,'Ps','color','k','FontSize',15,'Fontweight','bold');
text(15,18.5,'PpPs','color','k','FontSize',15,'Fontweight','bold');
text(15,23.5,'PpSs+PsPs','color','k','FontSize',15,'Fontweight','bold');
set(gcf,'position',[600,400,550,420]);

figure; wigb(seis_Rn(1:Nt,1:Ntraces),2,[1:Ntraces],[dt*(0:Nt-1)-tshft]);
ylabel('Time (s)','Fontsize',20);
xlabel('Traces','Fontsize',20);
yticks([0 10 20 30 40]);
title('Radial Seismograms (noisy)','Fontsize',16);
set(gca,'Fontsize',20,'Linewidth',1.2,'position',[0.23 0.17 0.55 0.73],'XAxisLocation','bottom');
text(15,2.5,'P','color','k','FontSize',15,'Fontweight','bold');
text(15,7,'Ps','color','k','FontSize',15,'Fontweight','bold');
text(15,18.5,'PpPs','color','k','FontSize',15,'Fontweight','bold');
text(15,23.5,'PpSs+PsPs','color','k','FontSize',15,'Fontweight','bold');
set(gcf,'position',[600,400,550,420]);

figure; wigb(rf_mc(1:Nt,1:Ntraces),2,[1:Ntraces],[dt*(0:Nt-1)-tshft]);
ylabel('Time (s)','Fontsize',20);
xlabel('Traces','Fontsize',20);
yticks([0 10 20 30 40]);
title('RF estimates','Fontsize',16);
set(gca,'Fontsize',20,'Linewidth',1.2,'position',[0.23 0.17 0.55 0.73],'XAxisLocation','bottom');
text(15,2.5,'P','color','k','FontSize',15,'Fontweight','bold');
text(15,7,'Ps','color','k','FontSize',15,'Fontweight','bold');
text(15,18.5,'PpPs','color','k','FontSize',15,'Fontweight','bold');
text(15,23.5,'PpSs+PsPs','color','k','FontSize',15,'Fontweight','bold');
set(gcf,'position',[600,400,550,420]);